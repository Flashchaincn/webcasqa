#!/usr/bin/env bash
function symlink_contents_to_dir() {
if [[ -z "$1" ]]; then
echo "arg 1 to symlink_contents_to_dir is unexpectedly empty"
exit 1
fi
if [[ -z "$2" ]]; then
echo "arg 2 to symlink_contents_to_dir is unexpectedly empty"
exit 1
fi
local target="$2"
mkdir -p "$target"
if [[ -f "$1" ]]; then
symlink_to_dir "$1" "$target"
elif [[ -L "$1" ]]; then
local actual=$(readlink "$1")
symlink_contents_to_dir "$actual" "$target"
elif [[ -d "$1" ]]; then
SAVEIFS=$IFS
IFS=$'
'
local children=($(find -H "$1" -maxdepth 1 -mindepth 1))
IFS=$SAVEIFS
for child in "${children[@]:-}"; do
symlink_to_dir "$child" "$target"
done
fi
}
function symlink_to_dir() {
if [[ -z "$1" ]]; then
echo "arg 1 to symlink_to_dir is unexpectedly empty"
exit 1
fi
if [[ -z "$2" ]]; then
echo "arg 2 to symlink_to_dir is unexpectedly empty"
exit 1
fi
local target="$2"
mkdir -p "$target"
if [[ -f "$1" ]]; then
# In order to be able to use `replace_in_files`, we ensure that we create copies of specfieid
# files so updating them is possible.
if [[ "$1" == *.pc || "$1" == *.la || "$1" == *-config || "$1" == *.mk || "$1" == *.cmake ]]; then
dest="$target/$(basename "$1")"
cp "$1" "$dest" && chmod +w "$dest" && touch -r "$1" "$dest"
else
ln -s -f -t "$target" "$1"
fi
elif [[ -L "$1" && ! -d "$1" ]]; then
cp -pR "$1" "$2"
elif [[ -d "$1" ]]; then
SAVEIFS=$IFS
IFS=$'
'
local children=($(find -H "$1" -maxdepth 1 -mindepth 1))
IFS=$SAVEIFS
local dirname=$(basename "$1")
mkdir -p "$target/$dirname"
for child in "${children[@]:-}"; do
if [[ -n "$child" && "$dirname" != *.ext_build_deps ]]; then
symlink_to_dir "$child" "$target/$dirname"
fi
done
else
echo "Can not copy $1"
fi
}
function children_to_path() {
if [ -d $EXT_BUILD_DEPS/bin ]; then
local tools=$(find "$EXT_BUILD_DEPS/bin" -maxdepth 1 -mindepth 1)
for tool in $tools;
do
if  [[ -d "$tool" ]] || [[ -L "$tool" ]]; then
export PATH=$PATH:$tool
fi
done
fi
}
function replace_in_files() {
if [ -d "$1" ]; then
SAVEIFS=$IFS
IFS=$'
'
# Find all real files. Symlinks are assumed to be relative to something within the directory we're seaching and thus ignored
local files=$(find -P "$1" \( -type f -and \( -name "*.pc" -or -name "*.la" -or -name "*-config" -or -name "*.mk" -or -name "*.cmake" \) \))
IFS=$SAVEIFS
for file in ${files[@]}; do
local backup=$(mktemp)
touch -r "${file}" "${backup}"
sed -i 's@'"$2"'@'"$3"'@g' "${file}"
if [[ "$?" -ne "0" ]]; then
exit 1
fi
touch -r "${backup}" "${file}"
rm "${backup}"
done
fi
}
echo """"
echo ""Bazel external C/C++ Rules. Building library 'cpp_http'""
echo """"
set -euo pipefail
export EXT_BUILD_ROOT=$(pwd)
export INSTALLDIR=$EXT_BUILD_ROOT/bazel-out/k8-opt/bin/cpp_http
export BUILD_TMPDIR=$INSTALLDIR.build_tmpdir
export EXT_BUILD_DEPS=$INSTALLDIR.ext_build_deps
export PATH="$EXT_BUILD_ROOT:$PATH"
rm -rf $BUILD_TMPDIR
rm -rf $EXT_BUILD_DEPS
mkdir -p $INSTALLDIR
mkdir -p $BUILD_TMPDIR
mkdir -p $EXT_BUILD_DEPS
echo ""Environment:______________""
env
echo ""__________________________""
mkdir -p $EXT_BUILD_DEPS/lib
symlink_contents_to_dir $EXT_BUILD_ROOT/bazel-out/k8-opt/bin/external/boringssl/libssl.a $EXT_BUILD_DEPS/lib
symlink_contents_to_dir $EXT_BUILD_ROOT/bazel-out/k8-opt/bin/external/boringssl/libssl.pic.a $EXT_BUILD_DEPS/lib
symlink_contents_to_dir $EXT_BUILD_ROOT/bazel-out/k8-opt/bin/_solib_k8/libexternal_Sboringssl_Slibssl.so $EXT_BUILD_DEPS/lib
symlink_contents_to_dir $EXT_BUILD_ROOT/bazel-out/k8-opt/bin/external/boringssl/libcrypto.a $EXT_BUILD_DEPS/lib
symlink_contents_to_dir $EXT_BUILD_ROOT/bazel-out/k8-opt/bin/external/boringssl/libcrypto.pic.a $EXT_BUILD_DEPS/lib
symlink_contents_to_dir $EXT_BUILD_ROOT/bazel-out/k8-opt/bin/_solib_k8/libexternal_Sboringssl_Slibcrypto.so $EXT_BUILD_DEPS/lib
mkdir -p $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/aes/aes.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/aes/aes_nohw.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/aes/key_wrap.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/aes/mode_wrappers.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/bn/add.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/bn/asm/x86_64-gcc.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/bn/bn.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/bn/bytes.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/bn/cmp.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/bn/ctx.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/bn/div.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/bn/div_extra.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/bn/exponentiation.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/bn/gcd.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/bn/gcd_extra.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/bn/generic.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/bn/jacobi.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/bn/montgomery.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/bn/montgomery_inv.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/bn/mul.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/bn/prime.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/bn/random.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/bn/rsaz_exp.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/bn/shift.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/bn/sqrt.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/cipher/aead.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/cipher/cipher.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/cipher/e_aes.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/cipher/e_des.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/des/des.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/dh/check.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/dh/dh.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/digest/digest.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/digest/digests.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/ec/ec.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/ec/ec_key.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/ec/ec_montgomery.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/ec/felem.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/ec/oct.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/ec/p224-64.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/ec/p256-x86_64.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/ec/p256.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/ec/scalar.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/ec/simple.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/ec/simple_mul.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/ec/util.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/ec/wnaf.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/ecdh/ecdh.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/ecdsa/ecdsa.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/hmac/hmac.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/md4/md4.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/md5/md5.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/modes/cbc.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/modes/cfb.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/modes/ctr.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/modes/gcm.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/modes/gcm_nohw.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/modes/ofb.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/modes/polyval.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/rand/ctrdrbg.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/rand/fork_detect.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/rand/rand.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/rand/urandom.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/rsa/blinding.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/rsa/padding.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/rsa/rsa.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/rsa/rsa_impl.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/self_check/fips.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/self_check/self_check.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/sha/sha1-altivec.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/sha/sha1.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/sha/sha256.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/sha/sha512.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/tls/kdf.c $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/asn1/charmap.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/asn1/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/bio/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/bytestring/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/chacha/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/cipher_extra/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/conf/conf_def.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/conf/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/cpu_arm_linux.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/curve25519/curve25519_tables.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/curve25519/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/dsa/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/ec_extra/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/err/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/evp/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/aes/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/bn/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/bn/rsaz_exp.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/cipher/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/delocate.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/des/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/digest/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/digest/md32_common.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/ec/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/ec/p256-x86_64-table.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/ec/p256-x86_64.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/ec/p256_table.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/ecdsa/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/md5/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/modes/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/rand/fork_detect.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/rand/getrandom_fillin.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/rand/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/rsa/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/sha/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/fipsmodule/tls/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/hrss/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/lhash/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/obj/obj_dat.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/pkcs7/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/pkcs8/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/poly1305/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/pool/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/trust_token/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/x509/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/x509v3/ext_dat.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/crypto/x509v3/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/third_party/fiat/curve25519_32.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/third_party/fiat/curve25519_64.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/third_party/fiat/p256_32.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/third_party/fiat/p256_64.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/ssl/internal.h $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/external/boringssl/src/include $EXT_BUILD_DEPS/include
symlink_contents_to_dir $EXT_BUILD_ROOT/bazel-out/k8-opt/bin/external/boringssl/src/include $EXT_BUILD_DEPS/include
mkdir -p $EXT_BUILD_DEPS/bin
symlink_to_dir $EXT_BUILD_ROOT/external/cmake-3.22.1-linux-x86_64/bin $EXT_BUILD_DEPS/bin/
symlink_to_dir $EXT_BUILD_ROOT/bazel-out/k8-opt-exec-2B5CBBC6/bin/external/rules_foreign_cc/toolchains $EXT_BUILD_DEPS/bin/
children_to_path $EXT_BUILD_DEPS/bin
export PATH="$EXT_BUILD_DEPS/bin:$PATH"
cd $BUILD_TMPDIR
__var_CMAKE_AR="/usr/bin/ar"
__var_CMAKE_ASM_FLAGS_INIT="-U_FORTIFY_SOURCE -fstack-protector -Wall -Wunused-but-set-parameter -Wno-free-nonheap-object -fno-omit-frame-pointer -g0 -O2 -D_FORTIFY_SOURCE=1 -DNDEBUG -ffunction-sections -fdata-sections -fno-canonical-system-headers -Wno-builtin-macro-redefined -D__DATE__=\\\\\\\"redacted\\\\\\\" -D__TIMESTAMP__=\\\\\\\"redacted\\\\\\\" -D__TIME__=\\\\\\\"redacted\\\\\\\""
__var_CMAKE_CXX_COMPILER="/usr/bin/gcc"
__var_CMAKE_CXX_FLAGS_INIT="-U_FORTIFY_SOURCE -fstack-protector -Wall -Wunused-but-set-parameter -Wno-free-nonheap-object -fno-omit-frame-pointer -g0 -O2 -D_FORTIFY_SOURCE=1 -DNDEBUG -ffunction-sections -fdata-sections -std=c++0x -fno-canonical-system-headers -Wno-builtin-macro-redefined -D__DATE__=\\\\\\\"redacted\\\\\\\" -D__TIMESTAMP__=\\\\\\\"redacted\\\\\\\" -D__TIME__=\\\\\\\"redacted\\\\\\\" -std=c++17"
__var_CMAKE_C_COMPILER="/usr/bin/gcc"
__var_CMAKE_C_FLAGS_INIT="-U_FORTIFY_SOURCE -fstack-protector -Wall -Wunused-but-set-parameter -Wno-free-nonheap-object -fno-omit-frame-pointer -g0 -O2 -D_FORTIFY_SOURCE=1 -DNDEBUG -ffunction-sections -fdata-sections -fno-canonical-system-headers -Wno-builtin-macro-redefined -D__DATE__=\\\\\\\"redacted\\\\\\\" -D__TIMESTAMP__=\\\\\\\"redacted\\\\\\\" -D__TIME__=\\\\\\\"redacted\\\\\\\""
__var_CMAKE_EXE_LINKER_FLAGS_INIT="-fuse-ld=gold -Wl,-no-as-needed -Wl,-z,relro,-z,now -B/usr/bin -pass-exit-codes -Wl,--gc-sections -lstdc++ -lm"
__var_CMAKE_SHARED_LINKER_FLAGS_INIT="-shared -fuse-ld=gold -Wl,-no-as-needed -Wl,-z,relro,-z,now -B/usr/bin -pass-exit-codes -Wl,--gc-sections -lstdc++ -lm"
cat > crosstool_bazel.cmake << EOF
set(CMAKE_AR "$__var_CMAKE_AR" CACHE FILEPATH "Archiver")
set(CMAKE_ASM_FLAGS_INIT "$__var_CMAKE_ASM_FLAGS_INIT")
set(CMAKE_CXX_COMPILER "$__var_CMAKE_CXX_COMPILER")
set(CMAKE_CXX_FLAGS_INIT "$__var_CMAKE_CXX_FLAGS_INIT")
set(CMAKE_C_COMPILER "$__var_CMAKE_C_COMPILER")
set(CMAKE_C_FLAGS_INIT "$__var_CMAKE_C_FLAGS_INIT")
set(CMAKE_EXE_LINKER_FLAGS_INIT "$__var_CMAKE_EXE_LINKER_FLAGS_INIT")
set(CMAKE_SHARED_LINKER_FLAGS_INIT "$__var_CMAKE_SHARED_LINKER_FLAGS_INIT")
EOF
set -x
$EXT_BUILD_ROOT/external/cmake-3.22.1-linux-x86_64/bin/cmake -DCMAKE_TOOLCHAIN_FILE="crosstool_bazel.cmake" -DCMAKE_BUILD_TYPE="Release" -DCMAKE_INSTALL_PREFIX="$INSTALLDIR" -DCMAKE_PREFIX_PATH="$EXT_BUILD_DEPS;external/boringssl/src/include;bazel-out/k8-opt/bin/external/boringssl/src/include" -DCMAKE_RANLIB="" -DCMAKE_MAKE_PROGRAM=$EXT_BUILD_ROOT/bazel-out/k8-opt-exec-2B5CBBC6/bin/external/rules_foreign_cc/toolchains/make/bin/make -G 'Unix Makefiles' $EXT_BUILD_ROOT/external/cpp_http
$EXT_BUILD_ROOT/external/cmake-3.22.1-linux-x86_64/bin/cmake --build . --config Release  
$EXT_BUILD_ROOT/external/cmake-3.22.1-linux-x86_64/bin/cmake --install . --config Release 
set +x
replace_in_files $INSTALLDIR $BUILD_TMPDIR \${EXT_BUILD_DEPS}
replace_in_files $INSTALLDIR $EXT_BUILD_DEPS \${EXT_BUILD_DEPS}
replace_in_files $INSTALLDIR $EXT_BUILD_ROOT \${EXT_BUILD_ROOT}
mkdir -p $EXT_BUILD_ROOT/bazel-out/k8-opt/bin/copy_cpp_http/cpp_http
cp -L -r --no-target-directory "$INSTALLDIR" "$EXT_BUILD_ROOT/bazel-out/k8-opt/bin/copy_cpp_http/cpp_http" && find "$EXT_BUILD_ROOT/bazel-out/k8-opt/bin/copy_cpp_http/cpp_http" -type f -exec touch -r "$INSTALLDIR" "{}" \;
cd $EXT_BUILD_ROOT
